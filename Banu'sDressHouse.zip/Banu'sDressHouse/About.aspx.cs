﻿using System;
using System.Web;
using System.Web.UI;

namespace FinalProject
{

    public partial class About : System.Web.UI.Page
    {
        public void button9Clicked(object sender, EventArgs args)
        {
            Response.Redirect("Login.aspx");
        }
    }
}
