﻿using System;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Label = System.Reflection.Emit.Label;

namespace FinalProject
{

    public partial class Login : System.Web.UI.Page
    {
        public void button1Clicked(object sender, EventArgs args)
        {
        
                    label1.Text = "Hello Welcome Home";     
              
        }

        public void button2Clicked(object sender, EventArgs args)
        {

            label2.Text = "Successful Login";
            username.Text = createdEmail.Text;

        }
    }
}
