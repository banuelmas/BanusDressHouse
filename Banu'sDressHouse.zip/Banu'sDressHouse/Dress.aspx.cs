﻿using System;
using System.Web;
using System.Web.UI;

namespace FinalProject
{

    public partial class Dress : System.Web.UI.Page
    {
        public int counter
        {
            get
            {
                if (ViewState["pcounter"] != null)
                {
                    return ((int)ViewState["pcounter"]);

                }
                else
                {
                    return 0;
                }
            }

            set
            {
                ViewState["pcounter"] = value;
            }
        }

        public void Page_Load(object Sender, EventArgs e)
        {
            lblCounter.Text = counter.ToString();
            counter++;
        }
    }
}
