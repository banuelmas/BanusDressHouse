﻿using System;
using System.Net.Mail;

namespace FinalProject
{

    public partial class Contact : System.Web.UI.Page
    {
        public void button11Clicked(object sender, EventArgs args)
        {
            Response.Redirect("Login.aspx");

        }

        public void button1Clicked(object sender, EventArgs args)
        {
            try
            {
                if (Page.IsValid)
                {

                    MailMessage mailMessage = new MailMessage();
                    mailMessage.From = new MailAddress("banumorgan@gmail.com");
                    mailMessage.To.Add("banumorgan@gmail.com");
                    mailMessage.Subject = txtSubject.Text;

                    mailMessage.Body = "<b>Sender Name: </b>" + txtName.Text + "<br>"
                        + "<b>Sender Email: </b>" + txtEmail.Text + "<br>"
                        + "<b>Comments: </b>" + txtComments.Text;

                    mailMessage.IsBodyHtml = true;

                    SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587);
                    smtpClient.EnableSsl = true;
                    smtpClient.Credentials = new System.Net.NetworkCredential("banumorgan@gmail.com", "Nutella34");

                    smtpClient.Send(mailMessage);

                    label1.Text = "Thank you for contacting us!";

                    txtName.Enabled = false;
                    txtEmail.Enabled = false;
                    txtComments.Enabled = false;
                    txtSubject.Enabled = false;
                    Button1.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                //Log - Event Viewer or table
                label1.Text = "There is unknown problem. Please try later.";
            }

        }

        public void buttonLoginClicked(object sender, EventArgs args)
        {
            Response.Redirect("Login.aspx");


        }

    }
}


         